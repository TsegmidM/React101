import React from "react";
import "./App.css";
// import CarOwners from "./car-owner/carOwner";
// import TodoList from "./todo-list/todo-list";
import HouseListing from "./airbnb/house-info";
import DemoUseState from "./components/useState-demo";
import DemoUseStateObj from "./components/useState-demo/object-example";
import FireworkState from "./components/useState-demo/fireworks";
import CounterComp from "./components/useState-demo/counter";
import StatusPicker from "./components/useState-demo/statusPicker";
import LanguagePicker from "./components/useState-demo/languagePicker";

function App() {
  return (
    <div className="App">
      {/* {<CarOwners/>} */}
      {/* {<TodoList/>} */}
      {<HouseListing/>}
      {/* <DemoUseStateObj/> */}
      {/* <FireworkState></FireworkState> */}
      {/* {<CounterComp></CounterComp>} */}
      {/* {<StatusPicker></StatusPicker>} */}
      {/* {<LanguagePicker></LanguagePicker>} */}
    </div>
  );
}

export default App;
